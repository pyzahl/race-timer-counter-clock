

/*
 * display.c
 *
 *  Created on: Apr 29, 2020
 *      Author: pzahl
 */

#include "main.h"
#include "display.h"

#include "rtc_ds1302.h"


extern void delay_us (uint16_t us);


// **************************************************
// INFO ONLY -- Race Display as reverse engineered...
// **************************************************
/*
Control Computer:
STM32F103c8  ... 64k (Like Arduino Nano)
Summary:
STM32 pin function to SERIAL LED interface:
595 R (DS)      RED-S-DATA   ---  PB14 --- STM32  (pin 27)
595 G (DS)    GREEN-S-DATA   ---  PC14-OSC32_IN --- STM32 (pin 3)
595 B (DS)     BLUE-S-DATA   ---  PB13 --- STM32 (pin 26)
595 * (ST_CP)  SERIAL-CLK    ---  PB12 --- STM32 (pin 25)
595 * (SH_CP)   Latch-CLK    ---  PB1  --- STM32 (pin 19)

Control Buttons:
Button PB1  -- PA4 (pin14)
Button PB2  -- PA5 (pin15)
Button PB3  -- PA6 (pin16)
Button PB4  -- PA7 (pin17)
Button MD -- PC13 (pin2)
Button S1 -- PA0 (pin11)
Button S2 -- PA1 (pin12)
Middle OnBoard Button -- PB2 (pin20)
OnBoard Button by USB -- BOOT0 (pin44)

LEDs from in segments A-G,P:

FRONT VIEW:

  AAA     AAA     AAA     AAA
 B   F   B   F   B   F   B   F
 B   F   B   F   B   F   B   F
  GGG     GGG     GGG     GGG
 C   E   C   E   C   E   C   E
 C   E   C   E   C   E   C   E
  DDD  P  DDD  P  DDD   P DDD  P

   2020     AAA     AAA     AAA
  40  10   B   F   B   F   B   F
  40  10   B   F   B   F   B   F
   8080     GGG     GGG     GGG
  01  04   C   E   C   E   C   E
  01  04   C   E   C   E   C   E
   0202  P  DDD  P  DDD   P DDD  P

R,G,B Data in parallel, 4 digits in one 4x8bit serial word:
Bit 0 … 7 -> { GBAFPEDC }
G=1, B=2, A=4, F=8, P=0x10, E=0x20, D=0x40, C=0x80
{{0, { AFEDCB }},
{1, { FE }},
{2, { AFGCD }},
{3, { AFGED }}.
{4, {BFGE}},
{5, {ABGED}},
{6, {ABGCED}},
{7, {AFE}},
{8, {ABFGCED}},
{9, {ABFGED}}}
{M, {FGCEP} {BGCE}}
*/


// 7 Segment LED Segment Values:
#define SEGM_C 1
#define SEGM_D 2
#define SEGM_E 4
#define SEGM_P 8
#define SEGM_F 0x10
#define SEGM_A 0x20
#define SEGM_B 0x40
#define SEGM_G 0x80

int Segments[8] = { SEGM_A, SEGM_B, SEGM_C, SEGM_D, SEGM_E, SEGM_F, SEGM_G, SEGM_P };

// Digit Values:
uint8_t DigitValue[25] = {
  SEGM_A+SEGM_F+SEGM_E+SEGM_D+SEGM_C+SEGM_B, // 0
  SEGM_F+SEGM_E,                             // 1
  SEGM_A+SEGM_F+SEGM_G+SEGM_C+SEGM_D,        // 2
  SEGM_A+SEGM_F+SEGM_G+SEGM_E+SEGM_D,        // 3
  SEGM_B+SEGM_F+SEGM_G+SEGM_E,               // 4
  SEGM_A+SEGM_B+SEGM_G+SEGM_E+SEGM_D,        // 5
  SEGM_A+SEGM_B+SEGM_G+SEGM_C+SEGM_E+SEGM_D, // 6
  SEGM_A+SEGM_F+SEGM_E,                      // 7
  SEGM_A+SEGM_B+SEGM_F+SEGM_G+SEGM_C+SEGM_E+SEGM_D, // 8
  SEGM_A+SEGM_B+SEGM_F+SEGM_G+SEGM_E+SEGM_D, // 9
  SEGM_G+SEGM_C+SEGM_E,                      // m  10
  SEGM_A+SEGM_B+SEGM_G+SEGM_C+SEGM_D,        // E  11
  SEGM_A+SEGM_B+SEGM_G+SEGM_C,               // F  12
  SEGM_A+SEGM_B+SEGM_C+SEGM_D,               // C  13
  SEGM_G+SEGM_C+SEGM_D+SEGM_E,               // o  14
  SEGM_A+SEGM_B+SEGM_G+SEGM_F,               // ^o 15
  SEGM_G+SEGM_C+SEGM_E,                      // n  16
  SEGM_G+SEGM_C+SEGM_E+SEGM_F,               // d  17
  SEGM_D+SEGM_C+SEGM_E,                      // u  18
  SEGM_B+SEGM_G+SEGM_C+SEGM_D,               // t  19
  SEGM_C,                                    // i  20
  SEGM_C+SEGM_G,                             // r  21
  SEGM_G,                                    // -  22
  SEGM_D,                                    // _  23
  0 // OFF                                   // " "24
};



// ****************************************************************
// Display Interface Control (Shift Register SM74HC595D 3x RBG x 4)
// ****************************************************************


#define LEDON  HIGH
#define LEDOFF LOW
#define CLK_T   10  // Clock 1/2 period us
#define SETUP_T 2   // Data Setup Time us

void Latch(){
	  latchPin (HIGH);
	  delay_us (SETUP_T);
	  latchPin (LOW);
}

void StartDisplayUpdate(void){
	  // take the latchPin low so
	  // the LEDs don't change while you're sending in bits:
	  latchPin (LOW);
	  clockPin (LOW);
	  delay_us (SETUP_T);
}

void FinishDisplayUpdate(void){
	  //take the latch pin high so the LEDs will light up:
	  Latch ();
	  RedDataPin (LOW);
	  GreenDataPin (LOW);
	  BlueDataPin (LOW);
	  delay_us (SETUP_T);
}

void ShiftOut(uint8_t color, uint8_t digit){
	uint8_t b = digit;
	for (int i=0; i<8; ++i){
		RedDataPin   (((b&1) && (color&1)) ? LEDON:LEDOFF);
		GreenDataPin (((b&1) && (color&2)) ? LEDON:LEDOFF);
		BlueDataPin  (((b&1) && (color&4)) ? LEDON:LEDOFF);
		b >>= 1;
		delay_us (SETUP_T);
		clockPin (HIGH);
		delay_us (CLK_T);
		clockPin (LOW);
		delay_us (CLK_T);
	}
}

void ShiftOutIndividualColor(uint8_t color[8], uint8_t digit){
	int b = digit;
	for (int i=0; i<8; ++i){
		RedDataPin   (((b&1) && (color[i]&1)) ? LEDON:LEDOFF);
		GreenDataPin (((b&1) && (color[i]&2)) ? LEDON:LEDOFF);
		BlueDataPin  (((b&1) && (color[i]&4)) ? LEDON:LEDOFF);
		b >>= 1;
		delay_us (SETUP_T);
		clockPin (HIGH);
		delay_us (CLK_T);
		clockPin (LOW);
		delay_us (CLK_T);
	}
}

// ******************************
// DISPLAY SUPPORT FUNCTIONS
// ******************************

void ClearDisplay (){
	StartDisplayUpdate();
	ShiftOut(0, 0); // Digit 4
	ShiftOut(0, 0); // Digit 2
	ShiftOut(0, 0); // Digit 3
	ShiftOut(0, 0); // Digit 4
	FinishDisplayUpdate();
}

void SetSegments (uint8_t color[4], uint8_t segm[4]){
	uint8_t cc[8];
	StartDisplayUpdate();
    for (int m=0; m<4; ++m){
    	for (int k=0; k<8; ++k) cc[k]=color[m];
    	ShiftOutIndividualColor(cc, segm[m]);
    }
	FinishDisplayUpdate();
}

void RunSegmentTest (){
	uint8_t cc[8];
	ClearDisplay ();
	for (int i=0; i<16; ++i){
	  StartDisplayUpdate();
	  for (int k=0; k<8; ++k) cc[k]=k+1+i;
	  ShiftOutIndividualColor(cc, DigitValue[8]);
	  ShiftOutIndividualColor(cc, DigitValue[8]);
	  ShiftOutIndividualColor(cc, DigitValue[8]);
	  ShiftOutIndividualColor(cc, DigitValue[8]);
	  FinishDisplayUpdate();
	  HAL_Delay (200);
	}
	ClearDisplay ();
	HAL_Delay (500);
}

void RunDisplayTest (){
	ClearDisplay ();
	for (int i=0; i<10; ++i){
	  StartDisplayUpdate();
	  ShiftOut(1+(i)%7, DigitValue[i%10]); // Digit 4
	  ShiftOut(1+(1+i)%7, DigitValue[(i+1)%10]); // Digit 2
	  ShiftOut(1+(2+i)%7, DigitValue[(i+2)%10]); // Digit 3
	  ShiftOut(1+(3+i)%7, DigitValue[(i+3)%10]); // Digit 4
	  FinishDisplayUpdate();
	  HAL_Delay (400);
	}
	ClearDisplay ();
	HAL_Delay (600);
}


// display one 4 digit number in color with dots options
void display_number(int numberToDisplay, int color, int dots){
  int digit1=10; // [10] -> 0 -> digit OF+SEGM_G+SEGM_EF
  int digit2=10;
  int digit3=10;
  int digit4=10;

  StartDisplayUpdate();

  if (numberToDisplay>=0){
    digit4 =  numberToDisplay%10;
    digit3 = (numberToDisplay/10)%10;
    digit2 = (numberToDisplay/100)%10;
    digit1 = (numberToDisplay/1000)%10;
  } else {
	    digit4 =  -numberToDisplay%10;
	    digit3 = (-numberToDisplay/10)%10;
	    digit2 = (-numberToDisplay/100)%10;
	    digit1 = DIGIT_Minus;
  }
  // shift out the bits for all digit with color, with dot options:
  ShiftOut(color, DigitValue[digit1] + (dots&1 ? SEGM_P:0)); // Digit 1
  ShiftOut(color, DigitValue[digit2] + (dots&2 ? SEGM_P:0)); // Digit 2
  ShiftOut(color, DigitValue[digit3] + (dots&4 ? SEGM_P:0)); // Digit 3
  ShiftOut(color, DigitValue[digit4] + (dots&8 ? SEGM_P:0)); // Digit 4

  FinishDisplayUpdate();

#ifdef STRIPLEDS
  static uint8_t hue = 64*color;
  static uint8_t sat = 255;
  static uint8_t val = 0;
  for (int i=0; i<NUMLEDS; i++){
    val = DigitValue[digit4]&Segments[i] ? 30:0;
    leds[i].setHSV( hue, sat, val);
  }
  FastLED.show();
#endif

#ifdef SERIAL_MONITOR
  if(digit1==10) Serial.print(" "); else Serial.print(digit1);
  if(digit2==10) Serial.print(" "); else Serial.print(digit2);
  if(digit3==10) Serial.print(" "); else Serial.print(digit3);
  if(digit4==10) Serial.print(" "); else Serial.print(digit4);
  Serial.print("  D=");
  Serial.print(dots);
  Serial.print("  Col =");
  Serial.print(color);
  Serial.println();
#endif
}

// display two 2 digit numbers in dual color with dots options
void display_two_numbers_leadzero(int numberToDisplayLeft, int numberToDisplayRight, int colorLeft, int colorRight, int dots){
  int digit1=DIGIT_OFF; // [10] -> 0 -> digit OFF
  int digit2=DIGIT_OFF;
  int digit3=DIGIT_OFF;
  int digit4=DIGIT_OFF;

  StartDisplayUpdate();

  if (numberToDisplayRight>=0){
    digit4 =  numberToDisplayRight%10;
    digit3 = (numberToDisplayRight/10)%10;
  }
  if (numberToDisplayLeft>=0){
    digit2 = (numberToDisplayLeft/1)%10;
    digit1 = (numberToDisplayLeft/10)%10;
    if (dots < 0 && digit1 == 0){
    	digit1=digit2;
    	if (dots&1)
   			digit2 = DIGIT_Minus;
    	else
			digit2 = DIGIT_OFF;
    }
  }

  // shift out the bits for left and right digit pairs in colors, with dot options:
  ShiftOut(colorLeft, DigitValue[digit1] + (dots&1 ? SEGM_P:0)); // Digit 1
  ShiftOut(colorLeft, DigitValue[digit2] + (dots&2 ? SEGM_P:0)); // Digit 2
  ShiftOut(colorRight, DigitValue[digit3] + (dots&4 ? SEGM_P:0)); // Digit 3
  ShiftOut(colorRight, DigitValue[digit4] + (dots&8 ? SEGM_P:0)); // Digit 4

  FinishDisplayUpdate();

#ifdef STRIPLEDS
  static uint8_t hue = 64*colorRight;
  static uint8_t sat = 255;
  static uint8_t val = 0;
  for (int i=0; i<NUMLEDS; i++){
    val = DigitVale[digit4]&Segments[i] ? 30:0;
    leds[i].setHSV( hue, sat, val);
  }
  FastLED.show();
#endif

#ifdef SERIAL_MONITOR
  if(digit1==10) Serial.print(" "); else Serial.print(digit1);
  if(digit2==10) Serial.print(" "); else Serial.print(digit2);
  Serial.print(":");
  if(digit3==10) Serial.print(" "); else Serial.print(digit3);
  if(digit4==10) Serial.print(" "); else Serial.print(digit4);
  Serial.print("  D=");
  Serial.print(dots);
  Serial.print("  Col LR=");
  Serial.print(colorLeft);
  Serial.print(colorRight);
  Serial.println();
#endif

}

// display two 2 digit numbers in dual color with dots options
void display_two_numbers(int numberToDisplayLeft, int numberToDisplayRight, int colorLeft, int colorRight, int dots){
  int digit1=DIGIT_OFF; // [10] -> 0 -> digit OFF
  int digit2=DIGIT_OFF;
  int digit3=DIGIT_OFF;
  int digit4=DIGIT_OFF;

  StartDisplayUpdate();

  if (numberToDisplayRight>=0){
    digit4 =  numberToDisplayRight%10;
    digit3 = (numberToDisplayRight/10)%10;
    if (digit3 == 0)
    		digit3 = DIGIT_OFF;
  }
  if (numberToDisplayLeft>=0){
    digit2 = (numberToDisplayLeft/1)%10;
    digit1 = (numberToDisplayLeft/10)%10;
    if (digit1 == 0)
    		digit1 = DIGIT_OFF;
  }

  // shift out the bits for left and right digit pairs in colors, with dot options:
  ShiftOut(colorLeft, DigitValue[digit1] + (dots&1 ? SEGM_P:0)); // Digit 1
  ShiftOut(colorLeft, DigitValue[digit2] + (dots&2 ? SEGM_P:0)); // Digit 2
  ShiftOut(colorRight, DigitValue[digit3] + (dots&4 ? SEGM_P:0)); // Digit 3
  ShiftOut(colorRight, DigitValue[digit4] + (dots&8 ? SEGM_P:0)); // Digit 4

  FinishDisplayUpdate();

#ifdef STRIPLEDS
  static uint8_t hue = 64*colorRight;
  static uint8_t sat = 255;
  static uint8_t val = 0;
  for (int i=0; i<NUMLEDS; i++){
    val = DigitVale[digit4]&Segments[i] ? 30:0;
    leds[i].setHSV( hue, sat, val);
  }
  FastLED.show();
#endif

#ifdef SERIAL_MONITOR
  if(digit1==10) Serial.print(" "); else Serial.print(digit1);
  if(digit2==10) Serial.print(" "); else Serial.print(digit2);
  Serial.print(":");
  if(digit3==10) Serial.print(" "); else Serial.print(digit3);
  if(digit4==10) Serial.print(" "); else Serial.print(digit4);
  Serial.print("  D=");
  Serial.print(dots);
  Serial.print("  Col LR=");
  Serial.print(colorLeft);
  Serial.print(colorRight);
  Serial.println();
#endif

}



// display Mode
void display_mode(int mode, int color[8]){
  int c = color[mode];
  int digit3 = (mode/10)%10;
  int digit4 = (mode/1)%10;

  StartDisplayUpdate();
  switch (mode){
  	  case 1:
		  ShiftOut(c, DigitValue[DIGIT_C]);
		  ShiftOut(c, DigitValue[DIGIT_n]);
		  ShiftOut(c, DigitValue[DIGIT_t]);
		  ShiftOut(c, DigitValue[DIGIT_r]);
		  break;
  	  case 2:
		  ShiftOut(c, DigitValue[DIGIT_t]);
		  ShiftOut(c, DigitValue[DIGIT_t]);
		  ShiftOut(0, 0); // Digit 3
		  ShiftOut(0, 0); // Digit 4
		  break;
  	  case 3:
		  ShiftOut(c, DigitValue[DIGIT_C]);
		  ShiftOut(c, DigitValue[DIGIT_r]);
		  ShiftOut(c, DigitValue[DIGIT_i]);
		  ShiftOut(c, DigitValue[DIGIT_t]);
		  break;
  	  case 4:
		  ShiftOut(c, DigitValue[DIGIT_C]);
		  ShiftOut(c, DigitValue[DIGIT_r]);
		  ShiftOut(c, DigitValue[DIGIT_i]);
		  ShiftOut(c, DigitValue[DIGIT_t]);
		  break;
  	  case 5:
		  ShiftOut(c, DigitValue[DIGIT_t]);
		  ShiftOut(c, DigitValue[DIGIT_i]);
		  ShiftOut(c, DigitValue[DIGIT_m]);
		  ShiftOut(c, DigitValue[DIGIT_r]);
		  break;
  	  default:
		  ShiftOut(c, DigitValue[DIGIT_m]);
		  ShiftOut(c, DigitValue[DIGIT_m]);
		  ShiftOut(c, DigitValue[digit3]); // Digit 3
		  ShiftOut(c, DigitValue[digit4]); // Digit 4
		  break;
}
  FinishDisplayUpdate();

#ifdef SERIAL_MONITOR
  Serial.print("MM ");
  Serial.print(digit3);
  Serial.print(digit4);
  Serial.println();
#endif
}

// display Error
void display_error(int errcode, int c1, int c2){
	  int digit3 = (errcode/10)%10;
	  int digit4 = (errcode/1)%10;

	  StartDisplayUpdate();
	  ShiftOut(c1, DigitValue[DIGIT_E]);
	  ShiftOut(c1, DigitValue[DIGIT_E]);
	  ShiftOut(c2, DigitValue[digit3]); // Digit 3
	  ShiftOut(c2, DigitValue[digit4]); // Digit 4
	  FinishDisplayUpdate();

	#ifdef SERIAL_MONITOR
	  Serial.print("EE ");
	  Serial.print(digit3);
	  Serial.print(digit4);
	  Serial.println();
	#endif
}




