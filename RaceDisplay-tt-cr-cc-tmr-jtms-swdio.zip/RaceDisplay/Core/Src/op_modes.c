/*
 * op_modes.c
 *
 *  Created on: Apr 29, 2020
 *      Author: pzahl
 */

#include "main.h"
#include "op_modes.h"
#include "display.h"
#include "rtc_ds1302.h"

// #define STORE_MODE_IN_RTC 0    // at index  -- THIS is not working right yet
// #define STORE_LAPS_IN_RTC 1    // starting at index  -- THIS is not working right yet
// #define STORE_TIMERS_IN_RTC 4  // starting at index  -- THIS is not working right yet

// Mode 1: Lap Counters. Manual. # Fields
#define NFields 6

// Modes 2..4 are Timers
// Timer 0: Down Timer  (Mode 2)
// Timer 1: Up Timer A  (Mode 3)
// Timer 2: Up Timer B  (Mode 4)
#define NUM_TIMERS 4 // MUST match with data init sets!

// COLOR SCHEMES
// LED Colors are defined via Bits 0,1,2 = Red,Green,Blue
int ColorLookup[8] = { 1, 2, 4, 3, 5, 7, 6, 0 }; // RED, GREEN, BLUE, YELLOW, VIOLET, CYAN, WHITE, BLACK

// Timer Color Scheme
int TimerColorRun[NUM_TIMERS]     = { 1, 4, 2, 2 }; // RED, GREEN, BLUE
int TimerColorSetup[NUM_TIMERS]   = { 4, 4, 2, 5 }; // YELLOW
int TimerColorStop[NUM_TIMERS]    = { 5, 5, 5, 4 }; // VIOLET
int TimerColorElapsed[NUM_TIMERS] = { 4, 4, 4, 4 }; // BLUE
int TimerColorSeconds[NUM_TIMERS] = { 1, 4, 2, 4 }; // = RunColors
int TimerMinutesPerHour[NUM_TIMERS] = { 100, 100, 100, 60 };
int TTTimerColorPre[3] = { 3, 2, 1 };   //

int mode_colors[8] = { 7, 1, 2, 4, 2, 1, 1, 1 };

// default minutes max per hour
//#define TIMER_MIN_MAX 59
#define TIMER_MIN_MAX 99

// ******************************
// OPERATION MODE TASKS
// non blocking state machine design
// ******************************

int last_op=-1;

void RunMode1 (void){
#ifdef STORE_LAPS_IN_RTC
	static int init=1;
#endif
	static int LapCnt[NFields] = { 10, 15, 20, -1, -1, -1 }; // default laps
	static int LapSel=0;

	static uint32_t td=100L;
	static uint32_t timeLastPress=0;
	static int lpress=0;
	static int state=1;
	static int uptodate=0;

	uint32_t now = HAL_GetTick();

#ifdef STORE_LAPS_IN_RTC
	if (init){
		for (int i=0; i<3; ++i)
			LapCnt[i] = rtc_read_reg (kRamAddress0+STORE_LAPS_IN_RTC+i);
		init = 0;
	}
#endif

	switch (state){
		case 0: // check controls
			// SHR
			if (ButtonS1Pin == BUTTON_PRESSED)
			  LapSel++, state=1;

			// SHL
			if (ButtonS2Pin == BUTTON_PRESSED)
			  LapSel--, state=1;

			LapSel += NFields;
			LapSel %= NFields; // cyclic

			// LapL++
			if (Button3Pin == BUTTON_PRESSED)
			  if (LapCnt[LapSel%NFields] < 99) // limit
				LapCnt[LapSel%NFields]++, state=2;

			// LapL--
			if (Button4Pin == BUTTON_PRESSED)
			  if (LapCnt[LapSel%NFields] >= 0) // limit
				LapCnt[LapSel%NFields]--, state=2;


			// LapR++
			if (Button1Pin == BUTTON_PRESSED)
			  if (LapCnt[(LapSel+1)%NFields] < 99)
				LapCnt[(LapSel+1)%NFields]++, state=2;

			// LapR--
			if (Button2Pin == BUTTON_PRESSED)
			  if (LapCnt[(LapSel+1)%NFields] >= 0)
				LapCnt[(LapSel+1)%NFields]--, state=2;

			if (state > 0){
				timeLastPress = now;
				uptodate = 0;
			} else
				lpress = 0;
			break;

		case 1: // delay until next check, repeat
			if (now - timeLastPress < 600) return;
			state = 0;
			break;

		case 2: // check for long press
			if (lpress)
			  td=100; // speedup on long press
			else
			  td=700; // 1st press

			if (now - timeLastPress < td) return;

			lpress= 1;
			state = 0;

#ifdef STORE_LAPS_IN_RTC
		for (int i=0; i<3; ++i)
				rtc_write_reg (kRamAddress0+STORE_LAPS_IN_RTC+i, (uint8_t )LapCnt[i]);
#endif

			break;

		default: state = 0; break;
	}

	if (state > 0){
		timeLastPress = now;
	}

	if (!uptodate || last_op != 1){
		display_two_numbers (LapCnt[LapSel%NFields], LapCnt[(LapSel+1)%NFields], ColorLookup[LapSel%NFields], ColorLookup[(LapSel+1)%NFields], 0);
		uptodate = 1;
		last_op=1;
	}
}

void RunModeTime (int index, int timer_dir){
   // Timer Modes 2,3,4 DATA
#ifdef STORE_TIMERS_IN_RTC
   // not enough storage to put all static vra in there!
#endif
  static int HHMM[NUM_TIMERS][2] = {{ 00,00 }, { 40,00 }, { 60,00 }, { 00,00 }};
  static uint32_t timeRef[NUM_TIMERS] = {0, 0, 0, 0}; // ms
  static int ssrstate[NUM_TIMERS] = {3,3,3,3};
  static int ssrstateP[NUM_TIMERS]= {0,0,3,0};
  static int go[NUM_TIMERS] = {0,0,0,0};
  static int timeElapsed[NUM_TIMERS]   = {0, 0, 0, 0}; // ms
  static int RTCtimeRef[NUM_TIMERS]    = {0, 0, 0, 0}; // sec
  static int RTCtimeElapsed[NUM_TIMERS]= {0, 0, 0, 0}; // sec
  static int RTCtimeRefms[NUM_TIMERS]  = {0, 0, 0, 0}; // ms offset
  static int state=0;
  int min_per_hour = TimerMinutesPerHour[index];

  // short term button timings
  static uint32_t td=100;
  static uint32_t timeLast=0;
  static uint32_t timeLastPress=0;
  static int lpress=0;
  static int indexLast=-1;

  static int uptodate=0;
  const int crun = TimerColorRun[index];
  const int cset = TimerColorSetup[index];
  const int cstop = TimerColorStop[index];
  const int celaps = TimerColorElapsed[index];
  const int csec = TimerColorSeconds[index];
  static int critsec_last=0;
  int set_hh;
  int set_mm;
  int set_ss=0;
  int hh, mm, ss;

  uint32_t now = HAL_GetTick();

  switch (state){
    case 0: // check controls
		// Start/Stop/Reset...
		if (ButtonS2Pin == BUTTON_PRESSED){
			if (ssrstate[index]==3){
				ssrstate[index]=1;
				ssrstateP[index]=0;
				state=1;
			}
		}
		if (ButtonS1Pin == BUTTON_PRESSED){
			ssrstate[index]++;
			state=1;
#if 0
			if (min_per_hour > 60)
				min_per_hour = 60;
			else
				min_per_hour = TIMER_MIN_MAX+1;
#endif
			state=1;
		}

		// HH++
		if (Button3Pin == BUTTON_PRESSED)
			if (HHMM[index][0] < 99){ // limit
				HHMM[index][0]++; state=2;
			}
		// HH--
		if (Button4Pin == BUTTON_PRESSED)
			if (HHMM[index][0] > 0){ // limit
				HHMM[index][0]--; state=2;
			}

		// MM++
		if (Button1Pin == BUTTON_PRESSED)
			if (HHMM[index][1] < (min_per_hour-1)){ // limit to 59 (normal HH:MM) or 99 (special) or what ever...
				HHMM[index][1]++; state=2;
			}
		// MM--
		if (Button2Pin == BUTTON_PRESSED)
			if (HHMM[index][1] > 0){ // limit
				HHMM[index][1]--; state=2;
			}
		if (state > 0){
			timeLastPress = now;
			uptodate = 0;
		} else
			lpress = 0;
		break;

	case 1: // delay until next check, repeat
		if (now - timeLastPress < 1500) return;
		state = 0;
		break;

	case 2: // check for long press
		if (lpress)
		  td=300; // speedup on long press
		else
		  td=1000; // 1st press

		if (now - timeLastPress < td) return;

		lpress= 1;
        state = 0;
        break;

    default: state = 0; break;
  }

  // Start/Stop/Reset state control
  if (ssrstate[index] != ssrstateP[index]){
	  if (ssrstate[index] > 3) ssrstate[index] = 1;
	  switch (ssrstate[index]){
		  case 1: // Start
			  timeRef[index] = now; // system tics
			  RTCtimeRef[index]   = rtc_get_seconds_of_day (); // seconds of day from external RTC DS1302
			  RTCtimeRefms[index] = now; // ms offset
			  go[index] = 1;
			  break;
		  case 2: // Stop
			  go[index] = 0;
			  break;
		  case 3: // Reset
			  go[index] = 0; timeElapsed[index] = 0; RTCtimeElapsed[index] = 0;
			  break;
		  default:
			  ssrstate[index] = 1;
			  break;
	  }
	  ssrstateP[index] = ssrstate[index];
  }

  if (state > 0)
    timeLastPress = now;

  if (now - timeLast < 200) return; // display refresh

  if (timeRef[index] == 0L)
    timeRef[index] = now;

  if (timer_dir > 0){ // Timer
	  set_hh = HHMM[index][0];
	  set_mm = HHMM[index][1];
  } else { // Down Counter
	  set_hh = 0;
	  set_mm = HHMM[index][0];
	  set_ss = HHMM[index][1];
  }

  if (go[index]){
    //timeElapsed[index] = now-timeRef[index];
    RTCtimeElapsed[index] = 1000*(rtc_get_seconds_of_day () - RTCtimeRef[index]); // seconds of day from external RTC DS1302
    // Auto Sub Second compensation RTC + Ticks
    if (RTCtimeRefms[index] > 1000){
    	if (RTCtimeElapsed[index] == 1){
    		RTCtimeRefms[index] = 1000 - (RTCtimeRefms[index] - now);
    	}
        timeElapsed[index] = now-timeRef[index];
    } else
        timeElapsed[index] = RTCtimeElapsed[index]-RTCtimeRefms[index];
  }

  int critsec = set_hh*(60*(min_per_hour)) + set_mm*60 + set_ss + timer_dir*timeElapsed[index]/1000; // use system tics

  hh = critsec/(60*(min_per_hour));
  mm = critsec/60-hh*(min_per_hour);
  ss = critsec-hh*(60*(min_per_hour))-mm*60;

  if (!uptodate || critsec_last!=critsec || indexLast!=index || last_op != index+2){
    if (critsec < 0){ // timer elapsed
        hh = -critsec/(60*(min_per_hour));
        mm = -critsec/60-hh*(min_per_hour);
        ss = -critsec-hh*(60*(min_per_hour))-mm*60;
        if (ss%2 == 0)
          if (hh > 0)
            display_two_numbers_leadzero (hh,mm, celaps, celaps, 0); // time elapsed (negative), show MM:SS red alternating on/off
          else
            display_two_numbers_leadzero (mm, ss, celaps, csec, 0); // time elapsed (negative), show MM:SS red alternating on/off
        else
          display_two_numbers_leadzero (-1, -1, 0, 0, 0); // OFF at even sec (BLINK)
    }else{
      switch (ssrstate[index]){
      case 1: // running (started)
		  if (hh > 0) // HH:MM
        	  if (index == 3){
        		  display_two_numbers_leadzero (hh, mm, crun, crun, -ss); // HH:MM : green
        	  } else
        		  display_two_numbers_leadzero (hh, mm, crun, crun, 0); // HH:MM : green
          else{ // MM:SS
        	  if (index == 0){
        		  switch (ss){
        		  	  case 29:
        		  	  case 59: display_two_numbers_leadzero (mm, ss, TTTimerColorPre[0], TTTimerColorPre[0], 0); break; // h=00, show seconds in blue
        		  	  case 30:
        		  	  case  0: display_two_numbers_leadzero (mm, ss, TTTimerColorPre[1], TTTimerColorPre[1], 0); break; // h=00, show seconds in blue
        		  	  default: display_two_numbers_leadzero (mm, ss, crun, csec, 0); break; // h=00, show seconds in blue
        		  }
        	  } else {
        		  display_two_numbers_leadzero (mm, ss, crun, csec, 0); // h=00, show seconds in blue
        	  }
          }
    	  break;
      case 2: // stopped
    	  if (hh > 0) // HH:MM
    		  display_two_numbers_leadzero (hh, mm, cstop, cstop, 0); // STOPPED state : blue
    	  else // MM:SS
    	  	  display_two_numbers_leadzero (mm, ss, cstop, csec, 0); // STOPPED state : blue
    	  break;
      case 3: // reset, hold mode, adjust time mode
    	  // always HH:MM for adjusting
    	  if (timer_dir > 0) // Timer
    		  display_two_numbers_leadzero (set_hh, set_mm, cset, cset, 0); // STOPPED SETUP state : blue
		  else
    		  display_two_numbers_leadzero (set_mm, set_ss, cset, cset, 0); // STOPPED SETUP state : blue
          break;
      default:
          display_error (1, 1, 1); // Error -- invalid mode
    	  break;
      }
    }
    uptodate = 1;
    critsec_last=critsec;
    last_op=index+2;
  }

  indexLast=index;
  timeLast = now;
}

// ******************************
// TESTING CODE ONLY
// ******************************

void RunTimerTest (void){
  static uint32_t timeLast=0;
  static uint32_t timeRef=0;
  static int run=1;
  uint32_t now = HAL_GetTick();

  if (now < timeLast+50)
	  return;

  if (Button2Pin == BUTTON_PRESSED) // reset
	  timeRef = now;

  if (Button1Pin == BUTTON_PRESSED){ // start/stop
	  timeLast = now;
	  run = run ? 0:1;
  }

  if (run){
	  uint32_t timeElapsed = (now-timeRef)/10;

	  int critsec = timeElapsed/100;

	  int hh = critsec/3600;
	  int mm = critsec/60-hh*60;
	  int ss = critsec-hh*3600-mm*60;

	  if (hh > 0)
		  display_two_numbers (hh, mm, 1,1, 0);
	  else if (mm > 0)
		  display_two_numbers (mm, ss, 1,2, 0);
	  else
		  display_two_numbers ((timeElapsed/100)%60, timeElapsed%100, 1,4, 0);
  }
}

void DisplayRTCDate (){
	  uint8_t rtc_yr, rtc_wd, rtc_mo, rtc_dy;

	  rtc_get_date(&rtc_yr, &rtc_mo, &rtc_dy, &rtc_wd);
	  display_two_numbers(20,rtc_yr, 1, 1, 0);
	  HAL_Delay (2000);
	  display_two_numbers(rtc_mo,rtc_dy, 1, 1, 0);
	  HAL_Delay (2000);
	  display_two_numbers(88,rtc_wd, 1, 1, 0);
	  HAL_Delay (2000);
}

void RunRTCClock (){
	static uint32_t timeLast=0;
	uint8_t rtc_h, rtc_m, rtc_s;
	uint32_t now = HAL_GetTick();

	if (now < timeLast+100)
		return;
	timeLast = HAL_GetTick();

	rtc_get_time(&rtc_h, &rtc_m, &rtc_s);
	if (rtc_s%10 == 0)
		display_two_numbers_leadzero(rtc_h,rtc_m, 4, 4, 0);
	else
		display_two_numbers_leadzero(rtc_m,rtc_s, 1, 1, 0);
}

extern uint8_t DigitValue[18];
void StandByMode(){
	static uint32_t timeLast=0;
	static uint8_t c = 1;
	uint32_t now = HAL_GetTick();
	uint8_t color[4] = { 0, 1, 2, 0 };
	uint8_t segm[4]  = { 0, DigitValue[DIGIT_Minus], DigitValue[DIGIT_Minus], 0 };

	if (now < timeLast+1000)
		return;
	timeLast = HAL_GetTick();

	if (c&1){
		color[1] = c, color[2]=0;
	} else {
		color[1] = 0, color[2]=c;
	}
	c++; c%=8;

	SetSegments (color, segm);
}

// ******************************
// MODE CONTROL state machine
// ******************************

int RunModeControl(int mmax){
  static uint32_t timeLast=0L;
  static int state=5;

#ifdef STORE_MODE_IN_RTC
  static int mode=-1;
  if (mode < 0)
		mode = rtc_read_reg (kRamAddress0+STORE_MODE_IN_RTC);
#else
  static int mode=0;
#endif

  if ((HAL_GetTick() - timeLast < 250)) return 0;
  switch (state){
    case 0:
      if (ButtonMDPin == BUTTON_PRESSED){
    	  ++mode;
    	  mode %= mmax;
#ifdef STORE_MODE_IN_RTC
    	  rtc_write_reg (kRamAddress0+STORE_MODE_IN_RTC, mode);
#endif
    	  state++;
      } else
    	  return mode+1;
      break;
    case 1: case 2: case 3: case 4: case 5: case 6: case 7: state++; break;
    default: state=0; break;
  }

  if (state>0){
    display_mode (mode+1, mode_colors);
    last_op = -1;
  }

  timeLast = HAL_GetTick();

  return 0;
}


